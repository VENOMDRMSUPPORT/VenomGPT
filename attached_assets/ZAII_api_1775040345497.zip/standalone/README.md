# Z.AI API Test Reports

Standalone test report system for Z.AI API with 12 GLM models and 8 capabilities.

## 📁 Project Structure

```
standalone/
├── lib/
│   └── audit-engine.mjs      # Core testing engine
├── reports/
│   ├── capabilities/         # 8 capability test reports
│   │   ├── INDEX.md         # Capabilities summary index
│   │   ├── 01-thinking-mode.md
│   │   ├── 02-deep-thinking.md
│   │   ├── 03-streaming-messages.md
│   │   ├── 04-function-calling.md
│   │   ├── 05-tool-streaming-output.md
│   │   ├── 06-structured-output.md
│   │   ├── 07-context-caching.md
│   │   ├── 08-context-caching-general.md
│   │   └── 09-context-caching-coding.md
│   └── models/              # 12 model reports
│       ├── INDEX.md         # Models summary index
│       ├── 01-glm-4.5.md
│       ├── 02-glm-4.5-air.md
│       ├── 03-glm-4.5-flash.md
│       ├── 04-glm-4.6.md
│       ├── 05-glm-4.7.md
│       ├── 06-glm-5.md
│       ├── 07-glm-5-turbo.md
│       ├── 08-glm-5.1.md
│       ├── 09-glm-4.6v.md
│       ├── 10-glm-4.6v-flash.md
│       ├── 11-glm-4.5v.md
│       └── 12-autoglm-phone-multilingual.md
├── index.html               # Main report page (STATIC - needs manual update)
└── run.mjs                  # Test runner script
```

---

## 🔄 Update Process

### Current Status: **DYNAMIC HTML** (Auto-Generated)

The `index.html` file is **fully automatic**. When you run tests:

1. **Test data** is generated from actual API calls
2. **Markdown reports** are auto-generated in `reports/` folders
3. **HTML file** is **auto-generated** with latest results

---

## 🚀 How to Update Reports

### Run Tests (Single Command)
```bash
node run.mjs
```

This automatically:
- Tests all 12 models across 3 API endpoints
- Tests all 8 capabilities
- Generates markdown reports in `reports/capabilities/` and `reports/models/`
- Generates `index.html` with **real test results**
- Updates all stats, status indicators, and links dynamically

### Output Files
- `index.html` - Auto-generated HTML report with live data
- `reports/capabilities/` - 8 capability reports (markdown)
- `reports/models/` - 12 model reports (markdown)
- `reports/models/models-report.json` - Raw test results (JSON)

---

## 📊 API Endpoints

| API Type | Endpoint | Protocol |
|----------|----------|----------|
| General | `https://api.z.ai/api/paas/v4/chat/completions` | OpenAI Compatible |
| Coding | `https://api.z.ai/api/coding/paas/v4/chat/completions` | OpenAI Compatible |
| Anthropic | `https://api.z.ai/api/anthropic/v1/messages` | Anthropic Compatible |

---

## 🧪 Tested Models (12)

### Language Models (8)
- `glm-4.5` - Stable baseline
- `glm-4.5-air` - Lightweight
- `glm-4.5-flash` - Ultra-fast
- `glm-4.6` - Enhanced with thinking
- `glm-4.7` - Latest 4.x
- `glm-5` - Premium deep thinking
- `glm-5-turbo` - Fast premium
- `glm-5.1` - Latest cutting-edge

### Vision Models (4)
- `glm-4.6v` - High-quality vision
- `glm-4.6v-flash` - Fast vision
- `glm-4.5v` - OCR & documents
- `autoglm-phone-multilingual` - Phone UI understanding

---

## ⚡ Tested Capabilities (8)

1. **thinking-mode** - Basic reasoning with `reasoning_content`
2. **deep-thinking** - Extended reasoning with `clear_thinking`
3. **streaming-messages** - SSE streaming
4. **function-calling** - Tool calls
5. **tool-streaming-output** - Streaming tool_calls
6. **structured-output** - JSON mode
7. **context-caching** - Coding API caching
8. **context-caching-general** - General API caching

---

## 📅 Last Test

- **Date**: April 1, 2026
- **Duration**: ~90 seconds
- **Success Rate**: 100%
- **Models Tested**: 12
- **Capabilities Tested**: 8

---

## 🔑 Required Environment

Set your API key:
```bash
export ZAI_API_KEY="your-api-key-here"
```

Or create `.env` file:
```
ZAI_API_KEY=your-api-key-here
```

---

## 📝 Notes

- All report files use real request/response examples
- Each model report includes 3 API examples (General, Coding, Anthropic)
- HTML is **auto-generated** - no manual updates needed
- HTML uses dark theme with responsive design
- Stats cards auto-layout: 4 cols → 2 cols (tablet) → 1 col (mobile)
