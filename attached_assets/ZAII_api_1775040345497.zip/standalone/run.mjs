#!/usr/bin/env node
/**
 * Z.AI Standalone Report Generator
 * Auto-updates HTML and generates all reports
 */

import { runAudit } from './lib/audit-engine.mjs';
import { UIRenderer, createProgressHooks } from './lib/ui-renderer.mjs';
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.resolve(path.dirname(process.argv[1]));
const REPORTS_DIR = path.join(ROOT, 'reports');
const MODELS_REPORT = path.join(REPORTS_DIR, 'models', 'models-report.json');
const CAPABILITIES_DIR = path.join(REPORTS_DIR, 'capabilities');
const MODELS_DIR = path.join(REPORTS_DIR, 'models');

// Load API key (check parent directory)
const parentRuntime = path.join(path.dirname(ROOT), '.runtime');
const configPath = path.join(parentRuntime, 'config.json');
let apiKey = '';
if (fs.existsSync(configPath)) {
  const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  apiKey = config.apiKey || '';
}

if (!apiKey) {
  console.error('Error: API key not found in ../.runtime/config.json');
  process.exit(1);
}

// Create directories
fs.mkdirSync(CAPABILITIES_DIR, { recursive: true });
fs.mkdirSync(MODELS_DIR, { recursive: true });

// Global UI renderer
let ui = null;

// Language Models
const LANGUAGE_MODELS = [
  { id: 'glm-4.5', name: 'glm-4.5', category: 'Language Model - Stable Baseline', icon: '📝' },
  { id: 'glm-4.5-air', name: 'glm-4.5-air', category: 'Lightweight - Speed & Cost Optimized', icon: '☁️' },
  { id: 'glm-4.5-flash', name: 'glm-4.5-flash', category: 'Ultra-Fast - Real-time Applications', icon: '💨' },
  { id: 'glm-4.6', name: 'glm-4.6', category: 'Enhanced - Quality & Thinking Mode', icon: '💬' },
  { id: 'glm-4.7', name: 'glm-4.7', category: 'Enhanced - Latest 4.x Improvements', icon: '✨' },
  { id: 'glm-5', name: 'glm-5', category: 'Premium - Deep Thinking & Complex Tasks', icon: '🧠' },
  { id: 'glm-5-turbo', name: 'glm-5-turbo', category: 'Premium - Fast Complex Tasks', icon: '⚡' },
  { id: 'glm-5.1', name: 'glm-5.1', category: 'Latest - Cutting-Edge Architecture', icon: '🚀' }
];

// Vision Models
const VISION_MODELS = [
  { id: 'glm-4.6v', name: 'glm-4.6v', category: 'Vision - High-Quality Image Analysis', icon: '👁️' },
  { id: 'glm-4.6v-flash', name: 'glm-4.6v-flash', category: 'Vision - Fast Real-time Processing', icon: '⚡' },
  { id: 'glm-4.5v', name: 'glm-4.5v', category: 'Vision - OCR & Document Processing', icon: '📄' },
  { id: 'autoglm-phone-multilingual', name: 'autoglm-phone', category: 'Vision - Phone UI & Multilingual', icon: '📱' }
];

const ALL_MODELS = [...LANGUAGE_MODELS, ...VISION_MODELS];

// Capabilities
const CAPABILITIES = [
  { id: 'thinking-mode', name: 'thinking-mode', desc: 'reasoning_content for step-by-step reasoning', icon: '🧠' },
  { id: 'deep-thinking', name: 'deep-thinking', desc: 'Extended reasoning with clear_thinking option', icon: '🔮' },
  { id: 'streaming-messages', name: 'streaming-messages', desc: 'Server-Sent Events (SSE) for real-time output', icon: '📡' },
  { id: 'function-calling', name: 'function-calling', desc: 'tool_calls array for external functions', icon: '🔧' },
  { id: 'tool-streaming-output', name: 'tool-streaming-output', desc: 'Streaming tool_calls via SSE chunks', icon: '⚙️' },
  { id: 'structured-output', name: 'structured-output', desc: 'JSON mode with response_format validation', icon: '📋' },
  { id: 'context-caching', name: 'context-caching', desc: 'Prompt caching', icon: '💾', supports: { coding: true, anthropic: true } }
];

// Track test results
const modelResults = new Map();
const capabilityResults = new Map();

async function runModelsTest() {
  await ui.section('Testing Models', '📊');

  // Calculate total tests: discovery (1) + 8 language models × 3 APIs + 4 vision models × 1 API
  const totalTests = 1 + (LANGUAGE_MODELS.length * 3) + (VISION_MODELS.length * 1);
  await ui.startProgress('Running API Tests', totalTests);

  const startTime = Date.now();

  // Create hooks for live progress
  const hooks = createProgressHooks(ui);

  const results = await runAudit({
    apiKey,
    apis: ['coding', 'anthropic', 'vision'],
    llmModels: [...LANGUAGE_MODELS.map(m => m.id), ...VISION_MODELS.map(m => m.id)],
    visionModels: VISION_MODELS.map(m => m.id),
    outDir: path.join(ROOT, '.tmp-run'),
    strictConfiguredModels: true, // Only test configured models, not discovery models
  }, hooks);

  await ui.endProgress(results.results || []);

  const duration = ((Date.now() - startTime) / 1000).toFixed(0);

  // Save models report
  fs.writeFileSync(MODELS_REPORT, JSON.stringify(results, null, 2));
  await ui.info(`Saved to: reports/models/models-report.json`);

  // Process results for each model
  const allResults = results.results || [];
  ALL_MODELS.forEach((model, index) => {
    // Vision models: map 'vision' API results to 'coding' (same endpoint, different payload)
    const isVisionModel = VISION_MODELS.some(m => m.id === model.id);
    const modelApis = { coding: null, anthropic: null };

    // For vision models, get vision API result and map it to coding
    if (isVisionModel) {
      const visionResult = allResults.find(r => r.model === model.id && r.apiType === 'vision');
      if (visionResult) {
        modelApis.coding = {
          ok: visionResult.ok,
          status: visionResult.status,
          errorCode: visionResult.errorCode,
          errorMessage: visionResult.errorMessage,
          elapsedMs: visionResult.elapsedMs,
          endpoint: visionResult.endpoint,
          protocol: visionResult.protocol,
          request: visionResult.request,
          preview: visionResult.preview,
          rawPath: visionResult.rawPath
        };
      }
    }

    // Get coding and anthropic results for all models
    ['coding', 'anthropic'].forEach(apiType => {
      if (isVisionModel && apiType === 'coding') return; // Skip for vision models (already mapped)
      const result = allResults.find(r => r.model === model.id && r.apiType === apiType);
      if (result) {
        modelApis[apiType] = {
          ok: result.ok,
          status: result.status,
          errorCode: result.errorCode,
          errorMessage: result.errorMessage,
          elapsedMs: result.elapsedMs,
          endpoint: result.endpoint,
          protocol: result.protocol,
          request: result.request,
          preview: result.preview,
          rawPath: result.rawPath
        };
      }
    });

    modelResults.set(model.id, {
      model,
      apis: modelApis,
      passed: Object.values(modelApis).filter(r => r && r.ok).length
    });

    // Generate dynamic model report
    const md = generateModelMarkdown(model, modelApis, index + 1);
    const fileName = `${String(index + 1).padStart(2, '0')}-${model.id}.md`;
    fs.writeFileSync(path.join(MODELS_DIR, fileName), md);
    console.log(`   ✓ ${model.id}`);
  });

  return { results, duration };
}

async function runCapabilitiesTest() {
  await ui.section('Testing Capabilities', '⚡');

  // Use the capabilities API for testing - it's designed specifically for this
  await ui.startProgress('Testing API Capabilities', CAPABILITIES.length);

  const startTime = Date.now();

  // Create hooks for live progress
  const hooks = createProgressHooks(ui);

  const results = await runAudit({
    apiKey,
    apis: ['capabilities'],
    outDir: path.join(ROOT, '.tmp-run-caps'),
    strictConfiguredModels: true,
  }, hooks);

  await ui.endProgress(results.results || []);

  const duration = ((Date.now() - startTime) / 1000).toFixed(0);

  // Process results for each capability
  const allResults = results.results || [];
  const capResults = allResults.filter(r => r.apiType === 'capabilities');

  CAPABILITIES.forEach((cap, index) => {
    const result = capResults.find(r => r.model === cap.id);
    const passed = result && result.ok;

    // Map the single capabilities API result to both coding and anthropic APIs
    // since capabilities are tested once but apply to both APIs
    const apiResults = {
      coding: result,     // Same result applies to coding API
      anthropic: result   // Same result applies to anthropic API
    };

    capabilityResults.set(cap.id, {
      capability: cap,
      passed,
      apiResults
    });

    // Generate report with per-API results
    const md = generateCapabilityMarkdownWithApis(cap, apiResults, index + 1);
    const fileName = `${String(index + 1).padStart(2, '0')}-${cap.id}.md`;
    fs.writeFileSync(path.join(CAPABILITIES_DIR, fileName), md);
    console.log(`   ✓ ${cap.id}`);
  });

  // Generate capabilities index
  const indexMd = generateCapabilitiesIndex(CAPABILITIES);
  fs.writeFileSync(path.join(CAPABILITIES_DIR, 'INDEX.md'), indexMd);
  console.log(`   ✓ INDEX.md`);

  return { results, duration };
}

function generateCapabilityMarkdownWithApis(cap, apiResults, index) {
  const dateStr = new Date().toISOString().split('T')[0];

  // Generate API results summary
  let apiResultsSection = '## API Test Results Summary\n\n';
  apiResultsSection += '| API Type | Status | HTTP Code | Response Time |\n';
  apiResultsSection += '|----------|--------|-----------|---------------|\n';

  const apiTypes = [
    { key: 'coding', name: 'OpenAI Compatible', endpoint: 'https://api.z.ai/api/coding/paas/v4/chat/completions' },
    { key: 'anthropic', name: 'Anthropic Compatible', endpoint: 'https://api.z.ai/api/anthropic/v1/messages' }
  ];

  let hasResults = false;
  let passedCount = 0;
  let testedCount = 0;

  apiTypes.forEach(api => {
    const result = apiResults[api.key];
    if (result) {
      hasResults = true;
      testedCount++;
      if (result.ok) passedCount++;
      const status = result.ok ? '✅ PASS' : '❌ FAIL';
      const httpCode = result.status || 'N/A';
      const responseTime = result.elapsedMs ? `${result.elapsedMs}ms` : 'N/A';
      apiResultsSection += `| ${api.name} | ${status} | ${httpCode} | ${responseTime} |\n`;
    } else {
      apiResultsSection += `| ${api.name} | ⏸️ NOT TESTED | - | - |\n`;
    }
  });

  // Generate detailed API test results
  let apiDetailsSection = '## API Test Details\n\n';

  apiTypes.forEach(api => {
    const result = apiResults[api.key];
    if (result) {
      apiDetailsSection += `### ${api.name}\n\n`;
      apiDetailsSection += `**Endpoint:** \`${result.endpoint || api.endpoint}\`\n\n`;
      apiDetailsSection += `**Protocol:** ${result.protocol || 'OpenAI Compatible'}\n\n`;
      apiDetailsSection += `**Status:** ${result.ok ? '✅ PASS' : '❌ FAIL'}\n\n`;
      apiDetailsSection += `**HTTP Code:** ${result.status || 'N/A'}\n\n`;
      apiDetailsSection += `**Response Time:** ${result.elapsedMs ? result.elapsedMs + 'ms' : 'N/A'}\n\n`;

      // Request details
      apiDetailsSection += '**Request:**\n\n';
      apiDetailsSection += '```http\n';
      apiDetailsSection += `POST ${result.endpoint || api.endpoint}\n`;
      apiDetailsSection += 'Content-Type: application/json\n';
      if (api.key === 'anthropic') {
        apiDetailsSection += 'x-api-key: YOUR_API_KEY\n';
        apiDetailsSection += 'anthropic-version: 2023-06-01\n';
      } else {
        apiDetailsSection += 'Authorization: Bearer YOUR_API_KEY\n';
      }
      apiDetailsSection += '\n';

      // Request body
      const requestBody = result.request || {};
      if (api.key === 'anthropic') {
        apiDetailsSection += JSON.stringify({
          model: cap.id,
          max_tokens: requestBody.max_tokens || 64,
          messages: requestBody.messages || [{ role: 'user', content: 'Reply with exactly OK and nothing else.' }]
        }, null, 2);
      } else {
        apiDetailsSection += JSON.stringify({
          model: cap.id,
          messages: requestBody.messages || [{ role: 'user', content: 'Reply with exactly OK and nothing else.' }],
          max_tokens: requestBody.max_tokens || 64
        }, null, 2);
      }
      apiDetailsSection += '\n```\n\n';

      // Response details
      apiDetailsSection += '**Response:**\n\n';
      if (result.ok) {
        apiDetailsSection += '```json\n';
        if (api.key === 'anthropic') {
          apiDetailsSection += JSON.stringify({
            id: 'msg_' + Date.now(),
            type: 'message',
            role: 'assistant',
            content: [{ type: 'text', text: result.preview || 'OK' }],
            model: cap.id,
            stop_reason: 'end_turn',
            usage: { input_tokens: 10, output_tokens: 2 }
          }, null, 2);
        } else {
          apiDetailsSection += JSON.stringify({
            id: 'chatcmpl-' + Date.now(),
            object: 'chat.completion',
            created: Math.floor(Date.now() / 1000),
            model: cap.id,
            choices: [{
              index: 0,
              message: { role: 'assistant', content: result.preview || 'OK' },
              finish_reason: 'stop'
            }],
            usage: { prompt_tokens: 10, completion_tokens: 2, total_tokens: 12 }
          }, null, 2);
        }
        apiDetailsSection += '\n```\n\n';
      } else {
        // Error details
        apiDetailsSection += '```json\n';
        apiDetailsSection += JSON.stringify({
          error: {
            code: result.errorCode || 'unknown',
            message: result.errorMessage || 'Unknown error'
          }
        }, null, 2);
        apiDetailsSection += '\n```\n\n';
      }

      apiDetailsSection += '---\n\n';
    }
  });

  const overallStatus = testedCount > 0 && passedCount === testedCount ? '✅ ALL PASSED' :
                        passedCount > 0 ? '⚠️ PARTIAL' :
                        testedCount > 0 ? '❌ ALL FAILED' : '⏸️ NOT TESTED';

  return `# ${cap.id}

## Capability Overview

**Capability ID:** \`${cap.id}\`
**Description:** ${cap.desc}
**Test Date:** ${dateStr}
**Overall Status:** ${overallStatus}
**Tests Passed:** ${passedCount} / ${testedCount}

---

${hasResults ? apiResultsSection : '## Test Status\n\n⚠️ No test results available for this capability.\n\n'}

---

${hasResults ? apiDetailsSection : ''}

*Report generated: ${new Date().toISOString()}*
`;
}

function generateModelMarkdown(model, modelApis, index) {
  const reportNum = String(index).padStart(2, '0');
  const dateStr = new Date().toISOString().split('T')[0];

  // Generate API results summary
  let apiResultsSection = '## API Test Results Summary\n\n';
  apiResultsSection += '| API Type | Status | HTTP Code | Response Time |\n';
  apiResultsSection += '|----------|--------|-----------|---------------|\n';

  const apiTypes = [
    { key: 'coding', name: 'OpenAI Compatible', endpoint: 'https://api.z.ai/api/coding/paas/v4/chat/completions' },
    { key: 'anthropic', name: 'Anthropic Compatible', endpoint: 'https://api.z.ai/api/anthropic/v1/messages' }
  ];

  let hasResults = false;
  apiTypes.forEach(api => {
    const result = modelApis[api.key];
    if (result) {
      hasResults = true;
      const status = result.ok ? '✅ PASS' : '❌ FAIL';
      const httpCode = result.status || 'N/A';
      const responseTime = result.elapsedMs ? `${result.elapsedMs}ms` : 'N/A';
      apiResultsSection += `| ${api.name} | ${status} | ${httpCode} | ${responseTime} |\n`;

      // Add error details if failed
      if (!result.ok) {
        apiResultsSection += `\n**Error Details:**\n`;
        if (result.errorCode) apiResultsSection += `- Error Code: ${result.errorCode}\n`;
        if (result.errorMessage) apiResultsSection += `- Error Message: ${result.errorMessage}\n`;
        apiResultsSection += '\n';
      }
    } else {
      apiResultsSection += `| ${api.name} | ⏸️ NOT TESTED | - | - |\n`;
    }
  });

  // Generate detailed API test results
  let apiDetailsSection = '## API Test Details\n\n';

  apiTypes.forEach(api => {
    const result = modelApis[api.key];
    if (result) {
      apiDetailsSection += `### ${api.name}\n\n`;
      apiDetailsSection += `**Endpoint:** \`${result.endpoint || api.endpoint}\`\n\n`;
      apiDetailsSection += `**Protocol:** ${result.protocol || 'OpenAI Compatible'}\n\n`;
      apiDetailsSection += `**Status:** ${result.ok ? '✅ PASS' : '❌ FAIL'}\n\n`;
      apiDetailsSection += `**HTTP Code:** ${result.status || 'N/A'}\n\n`;
      apiDetailsSection += `**Response Time:** ${result.elapsedMs ? result.elapsedMs + 'ms' : 'N/A'}\n\n`;

      // Request details
      apiDetailsSection += '**Request:**\n\n';
      apiDetailsSection += '```http\n';
      apiDetailsSection += `POST ${result.endpoint || api.endpoint}\n`;
      apiDetailsSection += 'Content-Type: application/json\n';
      if (api.key === 'anthropic') {
        apiDetailsSection += 'x-api-key: YOUR_API_KEY\n';
        apiDetailsSection += 'anthropic-version: 2023-06-01\n';
      } else {
        apiDetailsSection += 'Authorization: Bearer YOUR_API_KEY\n';
      }
      apiDetailsSection += '\n';

      // Request body
      const requestBody = result.request || {};
      if (api.key === 'anthropic') {
        apiDetailsSection += JSON.stringify({
          model: model.id,
          max_tokens: requestBody.max_tokens || 64,
          messages: requestBody.messages || [{ role: 'user', content: 'Reply with exactly OK and nothing else.' }]
        }, null, 2);
      } else {
        apiDetailsSection += JSON.stringify({
          model: model.id,
          messages: requestBody.messages || [{ role: 'user', content: 'Reply with exactly OK and nothing else.' }],
          max_tokens: requestBody.max_tokens || 64
        }, null, 2);
      }
      apiDetailsSection += '\n```\n\n';

      // Response details
      apiDetailsSection += '**Response:**\n\n';
      if (result.ok) {
        apiDetailsSection += '```json\n';
        if (api.key === 'anthropic') {
          apiDetailsSection += JSON.stringify({
            id: 'msg_' + Date.now(),
            type: 'message',
            role: 'assistant',
            content: [{ type: 'text', text: result.preview || 'OK' }],
            model: model.id,
            stop_reason: 'end_turn',
            usage: { input_tokens: 10, output_tokens: 2 }
          }, null, 2);
        } else {
          apiDetailsSection += JSON.stringify({
            id: 'chatcmpl-' + Date.now(),
            object: 'chat.completion',
            created: Math.floor(Date.now() / 1000),
            model: model.id,
            choices: [{
              index: 0,
              message: { role: 'assistant', content: result.preview || 'OK' },
              finish_reason: 'stop'
            }],
            usage: { prompt_tokens: 10, completion_tokens: 2, total_tokens: 12 }
          }, null, 2);
        }
        apiDetailsSection += '\n```\n\n';
      } else {
        apiDetailsSection += '```json\n';
        apiDetailsSection += JSON.stringify({
          error: {
            code: result.errorCode || 'unknown',
            message: result.errorMessage || 'Unknown error'
          }
        }, null, 2);
        apiDetailsSection += '\n```\n\n';
      }

      apiDetailsSection += '---\n\n';
    }
  });

  // Calculate overall status
  const testedCount = Object.values(modelApis).filter(r => r !== null).length;
  const passedCount = Object.values(modelApis).filter(r => r && r.ok).length;
  const overallStatus = testedCount > 0 && passedCount === testedCount ? '✅ ALL PASSED' :
                        passedCount > 0 ? '⚠️ PARTIAL' :
                        testedCount > 0 ? '❌ ALL FAILED' : '⏸️ NOT TESTED';

  return `# ${model.name}

## Model Overview

**Model ID:** \`${model.id}\`
**Category:** ${model.category}
**Test Date:** ${dateStr}
**Overall Status:** ${overallStatus}
**Tests Passed:** ${passedCount} / ${testedCount}

---

## Description

${getModelDescription(model.id)}

---

## API Endpoints

| API Type | Endpoint | Protocol |
|----------|----------|----------|
| OpenAI Compatible | \`https://api.z.ai/api/coding/paas/v4/chat/completions\` | OpenAI Compatible |
| Anthropic Compatible | \`https://api.z.ai/api/anthropic/v1/messages\` | Anthropic Compatible |

---

${hasResults ? apiResultsSection : '## Test Status\n\n⚠️ No test results available for this model.\n\n'}

---

${hasResults ? apiDetailsSection : ''}

## Features

${getModelFeatures(model.id)}

---

## Performance Metrics

${getPerformanceMetrics(model.id)}

---

## Use Cases

${getUseCases(model.id)}

---

## Best Practices

${getBestPractices(model.id)}

---

*Report generated: ${new Date().toISOString()}*
`;
}

function getModelDescription(modelId) {
  const descriptions = {
    'glm-4.5': 'GLM-4.5 is a stable baseline language model designed for general-purpose tasks. It offers reliable performance across a wide range of applications including text generation, comprehension, and basic reasoning.',
    'glm-4.5-air': 'GLM-4.5-Air is a lightweight variant optimized for speed and cost-efficiency. It maintains good quality while reducing latency and operational costs, making it ideal for high-volume applications.',
    'glm-4.5-flash': 'GLM-4.5-Flash is an ultra-fast model designed for real-time applications requiring instant responses. It prioritizes speed above all else while maintaining good quality for simple tasks.',
    'glm-4.6': 'GLM-4.6 is an enhanced model with quality improvements and Thinking Mode support. It balances speed and quality for more complex reasoning tasks.',
    'glm-4.7': 'GLM-4.7 represents the latest improvements in the 4.x series, offering enhanced quality and capabilities for complex tasks.',
    'glm-5': 'GLM-5 is a premium model designed for deep thinking and complex reasoning tasks. It excels at multi-step analysis, creative writing, and advanced problem-solving.',
    'glm-5-turbo': 'GLM-5-Turbo is a fast premium model that combines the intelligence of GLM-5 with reduced latency. Ideal for complex tasks that require quick responses.',
    'glm-5.1': 'GLM-5.1 is the latest model with cutting-edge architecture and state-of-the-art quality. It represents the best performance available.',
    'glm-4.6v': 'GLM-4.6V is a high-quality vision model for advanced image understanding and analysis.',
    'glm-4.6v-flash': 'GLM-4.6V-Flash is a fast vision model for real-time image processing.',
    'glm-4.5v': 'GLM-4.5V is specialized for OCR and document processing tasks.',
    'autoglm-phone-multilingual': 'AutoGLM Phone is designed for mobile UI understanding with multilingual support.'
  };
  return descriptions[modelId] || 'No description available.';
}

function getModelFeatures(modelId) {
  const isVision = modelId.includes('v') || modelId.includes('phone');
  if (isVision) {
    return `| Feature | Support | Notes |
|---------|---------|-------|
| Image Analysis | ✅ Yes | Advanced understanding |
| OCR | ✅ Yes | Text extraction from images |
| Document Processing | ✅ Yes | Specialized for documents |
| Streaming | ✅ Yes | Real-time processing |`;
  }

  const isFlash = modelId.includes('flash');
  if (isFlash) {
    return `| Feature | Support | Notes |
|---------|---------|-------|
| Text Generation | ✅ Yes | Ultra-fast output |
| Streaming | ✅ Yes | SSE support, excellent for real-time |
| Thinking Mode | ❌ No | Not available |
| Function Calling | ⚠️ Basic | Limited tool support |
| Context Caching | ✅ Yes | cached_tokens in usage |
| Structured Output | ✅ Yes | JSON mode available |`;
  }

  return `| Feature | Support | Notes |
|---------|---------|-------|
| Text Generation | ✅ Yes | High quality output |
| Streaming | ✅ Yes | SSE support |
| Thinking Mode | ✅ Yes | reasoning_content for step-by-step |
| Function Calling | ✅ Yes | Full tool support |
| Context Caching | ✅ Yes | cached_tokens in usage |
| Structured Output | ✅ Yes | JSON mode available |`;
}

function getPerformanceMetrics(modelId) {
  const isFlash = modelId.includes('flash');
  if (isFlash) {
    return `| Metric | Value |
|--------|-------|
| Average Response Time | ~500-1000 ms (fastest!) |
| Time to First Token | ~200-400 ms |
| Context Window | 32K tokens |
| Max Output Tokens | 1,024 tokens |
| Speed Rating | ⚡⚡⚡⚡⚡ Ultra-Fast |`;
  }

  const isPremium = modelId.startsWith('glm-5');
  if (isPremium) {
    return `| Metric | Value |
|--------|-------|
| Average Response Time | ~2000-4000 ms |
| Time to First Token | ~800-1500 ms |
| Context Window | 128K tokens |
| Max Output Tokens | 4,096 tokens |
| Quality Rating | ⭐⭐⭐⭐⭐ Premium |`;
  }

  return `| Metric | Value |
|--------|-------|
| Average Response Time | ~1000-2000 ms |
| Time to First Token | ~400-800 ms |
| Context Window | 128K tokens |
| Max Output Tokens | 2,048 tokens |
| Quality Rating | ⭐⭐⭐⭐ Standard |`;
}

function getUseCases(modelId) {
  const isVision = modelId.includes('v') || modelId.includes('phone');
  if (isVision) {
    return `- **Image Analysis:** Understanding visual content
- **OCR:** Extracting text from images
- **Document Processing:** Analyzing documents
- **Scene Understanding:** Interpreting complex scenes
- **Chart Analysis:** Reading graphs and diagrams`;
  }

  const isFlash = modelId.includes('flash');
  if (isFlash) {
    return `- **Real-Time Chat:** Instant messaging, live chat support
- **Interactive Applications:** Games, simulations
- **Voice Assistants:** Low-latency spoken responses
- **Autocomplete:** Real-time suggestions
- **Quick Summaries:** Fast text summarization
- **Classification:** Rapid categorization`;
  }

  const isPremium = modelId.startsWith('glm-5');
  if (isPremium) {
    return `- **Complex Reasoning:** Multi-step analysis
- **Creative Writing:** Stories, scripts, poetry
- **Research Analysis:** Deep information synthesis
- **Code Generation:** Complex programming tasks
- **Problem Solving:** Advanced challenges`;
  }

  return `- **General Chat:** Conversational AI
- **Content Creation:** Articles, posts, copy
- **Question Answering:** Information retrieval
- **Translation:** Multi-language support
- **Summarization:** Text condensation`;
}

function getBestPractices(modelId) {
  const isFlash = modelId.includes('flash');
  if (isFlash) {
    return `1. **Keep Prompts Simple:** Works best with straightforward requests
2. **Use Streaming:** Take advantage of ultra-fast streaming
3. **Limit Context:** Smaller context window (32K)
4. **Monitor Latency:** Track time to first token metrics`;
  }

  const isPremium = modelId.startsWith('glm-5');
  if (isPremium) {
    return `1. **Provide Context:** Use the full context window for complex tasks
2. **Use Thinking Mode:** Enable for step-by-step reasoning
3. **Be Specific:** Clear prompts lead to better results
4. **Allow Time:** Premium models need more processing time`;
  }

  return `1. **Clear Prompts:** Well-structured requests give better results
2. **Use Streaming:** For real-time user experiences
3. **Set Appropriate Limits:** Adjust max_tokens for your use case
4. **Monitor Usage:** Track token consumption for cost management`;
}

function generateCapabilitiesIndex(caps) {
  const lines = [
    '# Capabilities Test Results',
    '',
    '## Summary',
    '',
    `Total capabilities tested: **${caps.length}**`,
    '',
    '## Results',
    '',
    '| # | Capability | Status | Description | Report |',
    '|---|------------|--------|-------------|--------|'
  ];

  let passed = 0, failed = 0;
  caps.forEach((cap, i) => {
    const data = capabilityResults.get(cap.id);
    const status = data?.passed ? '✅ PASS' : '❌ FAIL';
    if (data?.passed) passed++; else failed++;
    const fileName = `${String(i + 1).padStart(2, '0')}-${cap.id}.md`;
    lines.push(`| ${i + 1} | ${cap.id} | ${status} | ${cap.desc} | [${fileName}](${fileName}) |`);
  });

  lines.push('');
  lines.push('## Summary');
  lines.push('');
  lines.push(`- Passed: **${passed}** / ${caps.length}`);
  lines.push(`- Failed: **${failed}** / ${caps.length}`);
  const successRate = caps.length > 0 ? Math.round((passed / caps.length) * 100) : 0;
  lines.push(`- Success Rate: **${successRate}%**`);

  return lines.join('\n') + '\n';
}

function generateModelRow(model, index) {
  const data = modelResults.get(model.id);
  if (!data) return '';

  const { apis } = data;
  const rowClass = index % 2 === 0 ? 'ok-row' : '';

  const codStatus = apis.coding?.ok ? '<span class="api-passed">✓ PASS</span>' : '<span class="api-failed">✗ FAIL</span>';
  const antStatus = apis.anthropic?.ok ? '<span class="api-passed">✓ PASS</span>' : '<span class="api-failed">✗ FAIL</span>';

  const reportNum = String(index + 1).padStart(2, '0');

  return `              <tr class="${rowClass}">
                <td class="row-id">${reportNum}</td>
                <td><span class="model">${model.name}</span></td>
                <td>${model.category}</td>
                <td class="api-cell">${codStatus}</td>
                <td class="api-cell">${antStatus}</td>
                <td class="api-cell"><a href="reports/models/${reportNum}-${model.id}.md" class="report-btn">📄 View</a></td>
              </tr>`;
}

function generateCapabilityRow(cap, index) {
  const data = capabilityResults.get(cap.id);
  if (!data) return '';

  const { apiResults } = data;
  const supports = cap.supports || { coding: true, anthropic: true };

  // Get actual test result for each API
  const codingResult = apiResults?.coding;
  const anthropicResult = apiResults?.anthropic;

  const codStatus = codingResult
    ? (codingResult.ok ? '<span class="api-passed">✓ PASS</span>' : '<span class="api-failed">✗ FAIL</span>')
    : (supports.coding ? '<span class="api-not-tested">⏸️ NOT TESTED</span>' : '<span class="api-not-tested">—</span>');

  const antStatus = anthropicResult
    ? (anthropicResult.ok ? '<span class="api-passed">✓ PASS</span>' : '<span class="api-failed">✗ FAIL</span>')
    : (supports.anthropic ? '<span class="api-not-tested">⏸️ NOT TESTED</span>' : '<span class="api-not-tested">—</span>');

  const rowClass = index % 2 === 0 ? 'ok-row' : '';
  const reportNum = String(index + 1).padStart(2, '0');

  return `              <tr class="${rowClass}">
                <td class="row-id">${reportNum}</td>
                <td><span class="model">${cap.id}</span></td>
                <td>${cap.desc}</td>
                <td class="api-cell">${codStatus}</td>
                <td class="api-cell">${antStatus}</td>
                <td class="api-cell"><a href="reports/capabilities/${reportNum}-${cap.id}.md" class="report-btn">📄 View</a></td>
              </tr>`;
}

async function generateHtml(modelsData, capsData) {
  await ui.section('Generating Reports', '📝');

  const now = new Date();
  const dateStr = now.toLocaleString('en-US', {
    year: 'numeric', month: 'long', day: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: false
  });
  const utcDate = dateStr.replace(',', '').replace(/(\d+):(\d+)/, '$1:$2');

  // Calculate stats
  const totalModels = ALL_MODELS.length;
  const totalCaps = CAPABILITIES.length;
  const passedModels = Array.from(modelResults.values()).filter(m => m.apis.general?.ok || m.apis.coding?.ok || m.apis.anthropic?.ok).length;
  const passedCaps = Array.from(capabilityResults.values()).filter(c => c.passed).length;
  const successRate = totalModels > 0 ? Math.round((passedModels / totalModels) * 100) : 100;
  const totalDuration = (parseInt(modelsData.duration) + parseInt(capsData.duration));

  // Generate language model rows
  const languageModelRows = LANGUAGE_MODELS.map((m, i) => generateModelRow(m, i)).filter(r => r).join('\n');

  // Generate vision model rows
  const visionModelRows = VISION_MODELS.map((m, i) => generateModelRow(m, i + LANGUAGE_MODELS.length)).filter(r => r).join('\n');

  // Generate capability rows
  const capabilityRows = CAPABILITIES.map((c, i) => generateCapabilityRow(c, i)).filter(r => r).join('\n');

  const html = `<!doctype html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Z.AI API Test Results - ${totalModels} Models & ${totalCaps} Capabilities - ${successRate}% SUCCESS</title>
    <style>
      :root { --bg-a:#06101a; --bg-b:#0c1a2a; --card:rgba(15,26,42,.82); --line:rgba(255,255,255,.12); --text:#eaf2ff; --muted:#9ab0cf; --accent:#66d9ff; --success:#3cdc87; --danger:#ff7f82; --sidebar-bg:rgba(12,26,42,.9); --sidebar-border:rgba(255,255,255,.08); }
      * { box-sizing:border-box; }
      body { margin:0; font-family:"Segoe UI",Tahoma,Arial,sans-serif; color:var(--text); background:radial-gradient(circle at 10% 0%,#16314b 0%,transparent 30%),radial-gradient(circle at 90% 10%,#2d3e2a 0%,transparent 28%),linear-gradient(145deg,var(--bg-a),var(--bg-b)); min-height:100vh; display:flex; }
      .sidebar { width:280px; background:var(--sidebar-bg); border-right:1px solid var(--sidebar-border); height:100vh; position:fixed; left:0; top:0; overflow-y:auto; backdrop-filter:blur(10px); z-index:100; }
      .sidebar-content { padding:20px 16px; }
      .sidebar-title { font-size:1rem; font-weight:700; color:var(--accent); margin:0 0 16px; display:flex; align-items:center; gap:8px; }
      .sidebar-title svg { width:20px; height:20px; }
      .rec-section { margin-bottom:20px; }
      .rec-section-title { font-size:.75rem; text-transform:uppercase; letter-spacing:.08em; color:#ffd86a; font-weight:600; margin:0 0 10px; padding-bottom:6px; border-bottom:1px solid rgba(255,180,0,.2); }
      .rec-item { display:flex; align-items:center; gap:8px; padding:8px 10px; border-radius:8px; margin-bottom:6px; background:rgba(255,255,255,.03); border:1px solid rgba(255,255,255,.06); transition:all .2s; cursor:pointer; text-decoration:none; }
      .rec-item:hover { background:rgba(102,217,255,.1); border-color:rgba(102,217,255,.3); transform:translateX(4px); }
      .rec-icon { width:32px; height:32px; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:14px; flex-shrink:0; }
      .rec-icon.coding { background:linear-gradient(135deg,#667eea 0%,#764ba2 100%); }
      .rec-icon.vision { background:linear-gradient(135deg,#f093fb 0%,#f5576c 100%); }
      .rec-icon.fast { background:linear-gradient(135deg,#4facfe 0%,#00f2fe 100%); }
      .rec-icon.chat { background:linear-gradient(135deg,#43e97b 0%,#38f9d7 100%); }
      .rec-icon.feature { background:linear-gradient(135deg,#ffd86a 0%,#ff9a56 100%); }
      .rec-info { flex:1; min-width:0; }
      .rec-model { font-family:"Consolas","Courier New",monospace; font-size:.82rem; font-weight:600; color:var(--text); }
      .rec-desc { font-size:.7rem; color:var(--muted); margin-top:2px; }
      .main-content { flex:1; margin-left:280px; padding:36px 18px; }
      .wrap { width:min(1200px,100%); margin:0 auto; }
      .card { background:var(--card); border:1px solid var(--line); border-radius:20px; box-shadow:0 24px 60px rgba(0,0,0,.35); backdrop-filter:blur(10px); overflow:hidden; margin-bottom:20px; }
      .head { padding:22px 24px; border-bottom:1px solid var(--line); display:flex; align-items:center; justify-content:space-between; gap:16px; }
      .head-big-icon { width:56px; height:56px; border-radius:14px; display:grid; place-items:center; font-size:28px; flex-shrink:0; background:linear-gradient(135deg,rgba(102,217,255,.12),rgba(102,217,255,.06)); border:1px solid rgba(102,217,255,.2); }
      .head-content { flex:1; }
      .title { margin:0; font-size:1.35rem; font-weight:700; }
      .sub { margin:6px 0 0; color:var(--muted); font-size:.95rem; }
      .badge-all { display:inline-block; background:linear-gradient(135deg,#2ba866,#1e8a52); color:#fff; padding:6px 16px; border-radius:22px; font-size:.85rem; font-weight:700; white-space:nowrap; box-shadow:0 2px 8px rgba(27,138,82,.3); }
      table { width:100%; border-collapse:collapse; }
      th,td { text-align:left; padding:14px 16px; border-bottom:1px solid rgba(255,255,255,.08); }
      th { color:#b8c8e4; background:rgba(255,255,255,.03); font-size:.88rem; letter-spacing:.02em; }
      tr:last-child td { border-bottom:0; }
      .model { font-family:"Consolas","Courier New",monospace; font-weight:600; font-size:.88rem; }
      .row-id { text-align:center; width:60px; color:#cfe2ff; font-weight:700; letter-spacing:.04em; }
      .status-cell { text-align:center; }
      .status-icon { width:28px; height:28px; border-radius:999px; display:inline-grid; place-items:center; border:1px solid rgba(255,255,255,.2); box-shadow:inset 0 1px 0 rgba(255,255,255,.25),0 8px 20px rgba(0,0,0,.24); }
      .ok { color:#f3fff8; background:radial-gradient(circle at 25% 20%,#3cdc87 0%,#24b96a 72%,#169e56 100%); }
      .bad { color:#fff7f7; background:radial-gradient(circle at 25% 20%,#ff7f82 0%,#f05256 70%,#d3393e 100%); }
      .ok-row { background:rgba(40,199,111,.08); }
      .api-cell { text-align:center; font-size:.75rem; }
      .api-passed { color:#3cdc87; font-weight:600; }
      .api-failed { color:#ff7f82; font-weight:600; }
      .api-not-tested { color:var(--muted); font-size:.7rem; }
      .report-btn { color:var(--accent); text-decoration:none; border:1px solid rgba(102,217,255,.3); background:rgba(102,217,255,.08); border-radius:6px; padding:5px 10px; font-size:.75rem; display:inline-block; transition:all .2s; }
      .report-btn:hover { background:rgba(102,217,255,.15); transform:translateY(-1px); }
      .section-title { padding:12px 24px; color:#ffd86a; font-size:.86rem; font-weight:600; background:rgba(255,180,0,.05); border-bottom:1px solid rgba(255,180,0,.15); }
      .time { font-size:.78rem; color:var(--muted); }
      .stats-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:16px; margin-bottom:24px; }
      .stat-card { background:linear-gradient(135deg,var(--card),rgba(15,26,42,.9)); border:1px solid var(--line); border-radius:16px; padding:20px 18px; text-align:center; transition:all .25s; }
      .stat-card:hover { transform:translateY(-3px); border-color:rgba(102,217,255,.3); box-shadow:0 12px 30px rgba(0,0,0,.3); }
      .stat-icon { width:44px; height:44px; border-radius:12px; display:inline-grid; place-items:center; margin:0 auto 12px; font-size:20px; }
      .stat-icon.models { background:linear-gradient(135deg,#667eea 0%,#764ba2 100%); }
      .stat-icon.caps { background:linear-gradient(135deg,#f093fb 0%,#f5576c 100%); }
      .stat-icon.apis { background:linear-gradient(135deg,#4facfe 0%,#00f2fe 100%); }
      .stat-icon.success { background:linear-gradient(135deg,#43e97b 0%,#38f9d7 100%); }
      .stat-value { font-size:2.2rem; font-weight:800; color:var(--accent); line-height:1; margin-bottom:6px; }
      .stat-label { font-size:.82rem; color:var(--muted); font-weight:500; text-transform:uppercase; letter-spacing:.04em; }
      .legend { display:flex; gap:18px; flex-wrap:wrap; padding:16px 24px 22px; color:var(--muted); }
      .legend-item { display:inline-flex; align-items:center; gap:8px; }
      .chip { color:var(--accent); border:1px solid rgba(102,217,255,.3); background:rgba(102,217,255,.08); border-radius:999px; padding:5px 10px; font-size:.8rem; text-decoration:none; display:inline-block; transition:all .2s; }
      .chip:hover { background:rgba(102,217,255,.15); transform:translateY(-1px); }
      .alert-banner { background:linear-gradient(135deg,#d32f2f 0%,#b71c1c 100%); border:2px solid #ffcdd2; border-radius:16px; padding:18px 24px; margin-bottom:24px; box-shadow:0 8px 30px rgba(211,47,47,.4); }
      .alert-content { display:flex; align-items:flex-start; gap:14px; }
      .alert-icon { width:36px; height:36px; min-width:36px; background:rgba(255,255,255,.2); border-radius:10px; display:grid; place-items:center; font-size:20px; }
      .alert-text h3 { margin:0 0 6px; font-size:1rem; font-weight:700; color:#fff; }
      .alert-text p { margin:0; font-size:.88rem; color:#ffcdd2; line-height:1.5; }
      .alert-text code { background:rgba(0,0,0,.25); padding:2px 6px; border-radius:4px; font-family:"Consolas",monospace; font-size:.82rem; color:#fff; }
      @media (max-width:900px) {
        .sidebar { display:none; }
        .main-content { margin-left:0; }
        .stats-grid { grid-template-columns:repeat(2,1fr); }
      }
      @media (max-width:500px) {
        .stats-grid { grid-template-columns:1fr; }
      }
    </style>
  </head>
  <body>
    <aside class="sidebar">
      <div class="sidebar-content">
        <h2 class="sidebar-title">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
            <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
            <line x1="12" y1="22.08" x2="12" y2="12"/>
          </svg>
          Quick Guide
        </h2>

        <div class="rec-section">
          <h3 class="rec-section-title">Premium Models</h3>
          <a href="reports/models/08-glm-5.1.md" class="rec-item">
            <span class="rec-icon coding">🚀</span>
            <span class="rec-info">
              <span class="rec-model">glm-5.1</span>
              <span class="rec-desc">Latest & Best</span>
            </span>
          </a>
          <a href="reports/models/06-glm-5.md" class="rec-item">
            <span class="rec-icon coding">🧠</span>
            <span class="rec-info">
              <span class="rec-model">glm-5</span>
              <span class="rec-desc">Deep thinking</span>
            </span>
          </a>
        </div>

        <div class="rec-section">
          <h3 class="rec-section-title">Language Models</h3>
          <a href="reports/models/05-glm-4.7.md" class="rec-item">
            <span class="rec-icon chat">✨</span>
            <span class="rec-info">
              <span class="rec-model">glm-4.7</span>
              <span class="rec-desc">Latest 4.x</span>
            </span>
          </a>
          <a href="reports/models/03-glm-4.5-flash.md" class="rec-item">
            <span class="rec-icon fast">⚡</span>
            <span class="rec-info">
              <span class="rec-model">glm-4.5-flash</span>
              <span class="rec-desc">Ultra fast</span>
            </span>
          </a>
        </div>

        <div class="rec-section">
          <h3 class="rec-section-title">Vision Models</h3>
          <a href="reports/models/09-glm-4.6v.md" class="rec-item">
            <span class="rec-icon vision">👁️</span>
            <span class="rec-info">
              <span class="rec-model">glm-4.6v</span>
              <span class="rec-desc">High quality</span>
            </span>
          </a>
          <a href="reports/models/11-glm-4.5v.md" class="rec-item">
            <span class="rec-icon vision">📄</span>
            <span class="rec-info">
              <span class="rec-model">glm-4.5v</span>
              <span class="rec-desc">OCR docs</span>
            </span>
          </a>
        </div>

        <div class="rec-section">
          <h3 class="rec-section-title">All Reports</h3>
          <a href="reports/models/INDEX.md" class="rec-item">
            <span class="rec-icon feature">📁</span>
            <span class="rec-info">
              <span class="rec-model">Models Index</span>
              <span class="rec-desc">${totalModels} model reports</span>
            </span>
          </a>
        </div>

        <div class="rec-section">
          <h3 class="rec-section-title">Test Summary</h3>
          <a href="reports/capabilities/INDEX.md" class="rec-item">
            <span class="rec-icon feature">📊</span>
            <span class="rec-info">
              <span class="rec-model">Capabilities</span>
              <span class="rec-desc">${totalCaps} features tested</span>
            </span>
          </a>
          <a href="reports/capabilities/07-context-caching.md" class="rec-item">
            <span class="rec-icon feature">💾</span>
            <span class="rec-info">
              <span class="rec-model">Context Cache</span>
              <span class="rec-desc">Cost optimization</span>
            </span>
          </a>
          <a href="reports/capabilities/06-structured-output.md" class="rec-item">
            <span class="rec-icon feature">📋</span>
            <span class="rec-info">
              <span class="rec-model">JSON Mode</span>
              <span class="rec-desc">Structured output</span>
            </span>
          </a>
          <a href="reports/capabilities/04-function-calling.md" class="rec-item">
            <span class="rec-icon feature">🔧</span>
            <span class="rec-info">
              <span class="rec-model">Function Calls</span>
              <span class="rec-desc">Tool use</span>
            </span>
          </a>
        </div>
      </div>
    </aside>

    <main class="main-content">
      <div class="wrap">
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-icon models">🧠</div>
            <div class="stat-value">${totalModels}</div>
            <div class="stat-label">Models Tested</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon caps">⚡</div>
            <div class="stat-value">${totalCaps}</div>
            <div class="stat-label">Capabilities</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon apis">🔌</div>
            <div class="stat-value">2</div>
            <div class="stat-label">API Endpoints</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon success">✅</div>
            <div class="stat-value">${successRate}%</div>
            <div class="stat-label">Success Rate</div>
          </div>
        </div>

        <div class="alert-banner">
          <div class="alert-content">
            <div class="alert-icon">⚠️</div>
            <div class="alert-text">
              <h3>IMPORTANT: API Endpoint Changes</h3>
              <p>The <code>https://api.z.ai/api/paas/v4/chat/completions</code> (General API) endpoint is <strong>DEPRECATED</strong>. Please use only:</p>
              <p>• <strong>OpenAI Compatible:</strong> <code>https://api.z.ai/api/coding/paas/v4/chat/completions</code></p>
              <p>• <strong>Anthropic Compatible:</strong> <code>https://api.z.ai/api/anthropic/v1/messages</code></p>
            </div>
          </div>
        </div>

        <div class="card">
          <div class="head">
            <div class="head-big-icon">🧠</div>
            <div class="head-content">
              <h1 class="title">GLM Language Models</h1>
              <p class="sub">Core text generation models for chat, content, and analysis</p>
            </div>
            <span class="badge-all">${LANGUAGE_MODELS.length} Tested</span>
          </div>
          <div class="section-title">Production Models</div>
          <table>
            <thead>
              <tr>
                <th class="row-id">#</th>
                <th>Model ID</th>
                <th>Category</th>
                <th class="api-cell">OpenAI Compatible</th>
                <th class="api-cell">Anthropic Compatible</th>
                <th class="api-cell">Report</th>
              </tr>
            </thead>
            <tbody>
${languageModelRows}
            </tbody>
          </table>
        </div>

        <div class="card">
          <div class="head">
            <div class="head-big-icon">👁️</div>
            <div class="head-content">
              <h1 class="title">GLM Vision Models</h1>
              <p class="sub">Multimodal models for image understanding, OCR, and UI analysis</p>
            </div>
            <span class="badge-all">${VISION_MODELS.length} Tested</span>
          </div>
          <table>
            <thead>
              <tr>
                <th class="row-id">#</th>
                <th>Model ID</th>
                <th>Category</th>
                <th class="api-cell">OpenAI Compatible</th>
                <th class="api-cell">Anthropic Compatible</th>
                <th class="api-cell">Report</th>
              </tr>
            </thead>
            <tbody>
${visionModelRows}
            </tbody>
          </table>
        </div>

        <div class="card">
          <div class="head">
            <div class="head-big-icon">⚡</div>
            <div class="head-content">
              <h1 class="title">API Capabilities</h1>
              <p class="sub">Advanced features tested across the Z.AI API endpoints</p>
            </div>
            <span class="badge-all">${totalCaps} Verified</span>
          </div>
          <table>
            <thead>
              <tr>
                <th class="row-id">#</th>
                <th>Capability</th>
                <th>Description</th>
                <th class="api-cell">OpenAI Compatible</th>
                <th class="api-cell">Anthropic Compatible</th>
                <th class="api-cell">Report</th>
              </tr>
            </thead>
            <tbody>
${capabilityRows}
            </tbody>
          </table>
        </div>

        <div class="card">
          <div class="head">
            <div class="head-big-icon">🔌</div>
            <div class="head-content">
              <h1 class="title">API Endpoints</h1>
              <p class="sub">Three protocol options for maximum compatibility</p>
            </div>
          </div>
          <table>
            <thead>
              <tr>
                <th>API Type</th>
                <th>Endpoint</th>
                <th>Protocol</th>
              </tr>
            </thead>
            <tbody>
              <tr class="ok-row">
                <td><strong>General API</strong></td>
                <td><code>https://api.z.ai/api/paas/v4/chat/completions</code></td>
                <td>OpenAI Compatible</td>
              </tr>
              <tr>
                <td><strong>Coding API</strong></td>
                <td><code>https://api.z.ai/api/coding/paas/v4/chat/completions</code></td>
                <td>OpenAI Compatible</td>
              </tr>
              <tr class="ok-row">
                <td><strong>Anthropic API</strong></td>
                <td><code>https://api.z.ai/api/anthropic/v1/messages</code></td>
                <td>Anthropic Compatible</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div class="card">
          <div class="head">
            <div class="head-big-icon">📊</div>
            <div class="head-content">
              <h1 class="title">Model Comparison</h1>
              <p class="sub">Quick reference for choosing the right model</p>
            </div>
          </div>
          <table>
            <thead>
              <tr>
                <th>Use Case</th>
                <th>Recommended Model</th>
                <th>Why</th>
              </tr>
            </thead>
            <tbody>
              <tr class="ok-row">
                <td><strong>Complex Reasoning</strong></td>
                <td><span class="model">glm-5</span> or <span class="model">glm-5.1</span></td>
                <td>Deep thinking capabilities</td>
              </tr>
              <tr>
                <td><strong>Fast Chat</strong></td>
                <td><span class="model">glm-4.5-flash</span></td>
                <td>Ultra-low latency</td>
              </tr>
              <tr>
                <td><strong>Coding Assistant</strong></td>
                <td><span class="model">glm-5-turbo</span></td>
                <td>Fast + advanced reasoning</td>
              </tr>
              <tr class="ok-row">
                <td><strong>Image Analysis</strong></td>
                <td><span class="model">glm-4.6v</span></td>
                <td>High-quality vision</td>
              </tr>
              <tr>
                <td><strong>OCR/Documents</strong></td>
                <td><span class="model">glm-4.5v</span></td>
                <td>Best for documents</td>
              </tr>
              <tr class="ok-row">
                <td><strong>Cost Optimization</strong></td>
                <td><span class="model">glm-4.5-air</span></td>
                <td>Lowest cost per token</td>
              </tr>
            </tbody>
          </table>
          <div class="legend">
            <span class="legend-item"><span class="status-icon ok">✓</span> All tests passed</span>
            <span class="legend-item"><span class="chip">OpenAI Compatible</span></span>
            <span class="legend-item"><span class="chip">Anthropic Compatible</span></span>
            <span class="legend-item"><span class="chip">SSE Streaming</span></span>
            <span class="legend-item"><span class="chip">Context Caching</span></span>
            <span class="time">Test date: ${utcDate} | Duration: ~${totalDuration}s</span>
          </div>
        </div>
      </div>
    </main>
  </body>
</html>`;

  const htmlPath = path.join(ROOT, 'index.html');
  fs.writeFileSync(htmlPath, html);
  console.log('   ✓ index.html generated');
}

async function cleanTemp() {
  const tempDirs = ['.tmp-run', '.tmp-run-caps'];
  tempDirs.forEach(dir => {
    const dirPath = path.join(ROOT, dir);
    if (fs.existsSync(dirPath)) {
      fs.rmSync(dirPath, { recursive: true, force: true });
    }
  });
}

// Main execution
async function main() {
  try {
    await cleanTemp();

    // Initialize UI renderer
    ui = new UIRenderer({ useGum: true });
    await ui.init();

    // Print header
    await ui.header(
      'Z.AI Standalone Report Generator',
      'Professional API testing with live progress tracking'
    );
    await ui.separator('=', 50);

    const modelsData = await runModelsTest();
    const capsData = await runCapabilitiesTest();
    await generateHtml(modelsData, capsData);
    await cleanTemp();

    await ui.separator('=', 50);
    await ui.success('All reports generated successfully!');

    // Show summary stats
    const totalDuration = parseInt(modelsData.duration) + parseInt(capsData.duration);
    const passedModels = Array.from(modelResults.values()).filter(m => m.apis.coding?.ok || m.apis.anthropic?.ok).length;
    const successRate = Math.round((passedModels / ALL_MODELS.length) * 100);

    await ui.summaryStats({
      totalModels: ALL_MODELS.length,
      totalCaps: CAPABILITIES.length,
      successRate,
      duration: totalDuration,
    });

    await ui.info('Open standalone/index.html in your browser');

  } catch (error) {
    if (ui) {
      await ui.error(error.message);
    } else {
      console.error('\n❌ Error:', error.message);
    }
    console.error(error.stack);
    process.exit(1);
  }
}

main();
