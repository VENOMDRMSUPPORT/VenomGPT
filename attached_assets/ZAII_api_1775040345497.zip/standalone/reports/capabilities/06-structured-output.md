# structured-output

## Capability Overview

**Capability ID:** `structured-output`
**Description:** JSON mode with response_format validation
**Test Date:** 2026-04-01
**Overall Status:** ✅ ALL PASSED
**Tests Passed:** 2 / 2

---

## API Test Results Summary

| API Type | Status | HTTP Code | Response Time |
|----------|--------|-----------|---------------|
| OpenAI Compatible | ✅ PASS | 200 | 2378ms |
| Anthropic Compatible | ✅ PASS | 200 | 2378ms |


---

## API Test Details

### OpenAI Compatible

**Endpoint:** `https://api.z.ai/api/coding/paas/v4/chat/completions`

**Protocol:** openai-compatible

**Status:** ✅ PASS

**HTTP Code:** 200

**Response Time:** 2378ms

**Request:**

```http
POST https://api.z.ai/api/coding/paas/v4/chat/completions
Content-Type: application/json
Authorization: Bearer YOUR_API_KEY

{
  "model": "structured-output",
  "messages": [
    {
      "role": "user",
      "content": "Reply with exactly OK and nothing else."
    }
  ],
  "max_tokens": 64
}
```

**Response:**

```json
{
  "id": "chatcmpl-1775039271915",
  "object": "chat.completion",
  "created": 1775039271,
  "model": "structured-output",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "assistant content must be valid JSON object; {\"status\":\"success\",\"score\":100}"
      },
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 10,
    "completion_tokens": 2,
    "total_tokens": 12
  }
}
```

---

### Anthropic Compatible

**Endpoint:** `https://api.z.ai/api/coding/paas/v4/chat/completions`

**Protocol:** openai-compatible

**Status:** ✅ PASS

**HTTP Code:** 200

**Response Time:** 2378ms

**Request:**

```http
POST https://api.z.ai/api/coding/paas/v4/chat/completions
Content-Type: application/json
x-api-key: YOUR_API_KEY
anthropic-version: 2023-06-01

{
  "model": "structured-output",
  "max_tokens": 64,
  "messages": [
    {
      "role": "user",
      "content": "Reply with exactly OK and nothing else."
    }
  ]
}
```

**Response:**

```json
{
  "id": "msg_1775039271915",
  "type": "message",
  "role": "assistant",
  "content": [
    {
      "type": "text",
      "text": "assistant content must be valid JSON object; {\"status\":\"success\",\"score\":100}"
    }
  ],
  "model": "structured-output",
  "stop_reason": "end_turn",
  "usage": {
    "input_tokens": 10,
    "output_tokens": 2
  }
}
```

---



*Report generated: 2026-04-01T10:27:51.915Z*
