# streaming-messages

## Capability Overview

**Capability ID:** `streaming-messages`
**Description:** Server-Sent Events (SSE) for real-time output
**Test Date:** 2026-04-01
**Overall Status:** ✅ ALL PASSED
**Tests Passed:** 2 / 2

---

## API Test Results Summary

| API Type | Status | HTTP Code | Response Time |
|----------|--------|-----------|---------------|
| OpenAI Compatible | ✅ PASS | 200 | 1799ms |
| Anthropic Compatible | ✅ PASS | 200 | 1799ms |


---

## API Test Details

### OpenAI Compatible

**Endpoint:** `https://api.z.ai/api/coding/paas/v4/chat/completions`

**Protocol:** openai-compatible

**Status:** ✅ PASS

**HTTP Code:** 200

**Response Time:** 1799ms

**Request:**

```http
POST https://api.z.ai/api/coding/paas/v4/chat/completions
Content-Type: application/json
Authorization: Bearer YOUR_API_KEY

{
  "model": "streaming-messages",
  "messages": [
    {
      "role": "user",
      "content": "Reply with exactly OK and nothing else."
    }
  ],
  "max_tokens": 64
}
```

**Response:**

```json
{
  "id": "chatcmpl-1775039271914",
  "object": "chat.completion",
  "created": 1775039271,
  "model": "streaming-messages",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "stream delta.content or delta.reasoning_content must be present; data: {\"id\":\"2026040118273723396fa2ed704986\",\"created\":1775039257,\"object\":\"chat.completion...."
      },
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 10,
    "completion_tokens": 2,
    "total_tokens": 12
  }
}
```

---

### Anthropic Compatible

**Endpoint:** `https://api.z.ai/api/coding/paas/v4/chat/completions`

**Protocol:** openai-compatible

**Status:** ✅ PASS

**HTTP Code:** 200

**Response Time:** 1799ms

**Request:**

```http
POST https://api.z.ai/api/coding/paas/v4/chat/completions
Content-Type: application/json
x-api-key: YOUR_API_KEY
anthropic-version: 2023-06-01

{
  "model": "streaming-messages",
  "max_tokens": 64,
  "messages": [
    {
      "role": "user",
      "content": "Reply with exactly OK and nothing else."
    }
  ]
}
```

**Response:**

```json
{
  "id": "msg_1775039271914",
  "type": "message",
  "role": "assistant",
  "content": [
    {
      "type": "text",
      "text": "stream delta.content or delta.reasoning_content must be present; data: {\"id\":\"2026040118273723396fa2ed704986\",\"created\":1775039257,\"object\":\"chat.completion...."
    }
  ],
  "model": "streaming-messages",
  "stop_reason": "end_turn",
  "usage": {
    "input_tokens": 10,
    "output_tokens": 2
  }
}
```

---



*Report generated: 2026-04-01T10:27:51.914Z*
