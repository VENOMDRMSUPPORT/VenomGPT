# glm-5-turbo

## Model Overview

**Model ID:** `glm-5-turbo`
**Category:** Premium - Fast Complex Tasks
**Test Date:** 2026-04-01
**Overall Status:** ✅ ALL PASSED
**Tests Passed:** 2 / 2

---

## Description

GLM-5-Turbo is a fast premium model that combines the intelligence of GLM-5 with reduced latency. Ideal for complex tasks that require quick responses.

---

## API Endpoints

| API Type | Endpoint | Protocol |
|----------|----------|----------|
| OpenAI Compatible | `https://api.z.ai/api/coding/paas/v4/chat/completions` | OpenAI Compatible |
| Anthropic Compatible | `https://api.z.ai/api/anthropic/v1/messages` | Anthropic Compatible |

---

## API Test Results Summary

| API Type | Status | HTTP Code | Response Time |
|----------|--------|-----------|---------------|
| OpenAI Compatible | ✅ PASS | 200 | 3250ms |
| Anthropic Compatible | ✅ PASS | 200 | 1338ms |


---

## API Test Details

### OpenAI Compatible

**Endpoint:** `https://api.z.ai/api/coding/paas/v4/chat/completions`

**Protocol:** openai-compatible

**Status:** ✅ PASS

**HTTP Code:** 200

**Response Time:** 3250ms

**Request:**

```http
POST https://api.z.ai/api/coding/paas/v4/chat/completions
Content-Type: application/json
Authorization: Bearer YOUR_API_KEY

{
  "model": "glm-5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Reply with exactly OK and nothing else."
    }
  ],
  "max_tokens": 64
}
```

**Response:**

```json
{
  "id": "chatcmpl-1775039253835",
  "object": "chat.completion",
  "created": 1775039253,
  "model": "glm-5-turbo",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "1.  **Analyze the Request:** The user is asking for a response consisting *exactly* of the word \"OK\" and absolutely nothing else.\n2.  **Identify Constraints:..."
      },
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 10,
    "completion_tokens": 2,
    "total_tokens": 12
  }
}
```

---

### Anthropic Compatible

**Endpoint:** `https://api.z.ai/api/anthropic/v1/messages`

**Protocol:** anthropic-compatible

**Status:** ✅ PASS

**HTTP Code:** 200

**Response Time:** 1338ms

**Request:**

```http
POST https://api.z.ai/api/anthropic/v1/messages
Content-Type: application/json
x-api-key: YOUR_API_KEY
anthropic-version: 2023-06-01

{
  "model": "glm-5-turbo",
  "max_tokens": 64,
  "messages": [
    {
      "role": "user",
      "content": "Reply with exactly OK and nothing else."
    }
  ]
}
```

**Response:**

```json
{
  "id": "msg_1775039253835",
  "type": "message",
  "role": "assistant",
  "content": [
    {
      "type": "text",
      "text": "OK"
    }
  ],
  "model": "glm-5-turbo",
  "stop_reason": "end_turn",
  "usage": {
    "input_tokens": 10,
    "output_tokens": 2
  }
}
```

---



## Features

| Feature | Support | Notes |
|---------|---------|-------|
| Text Generation | ✅ Yes | High quality output |
| Streaming | ✅ Yes | SSE support |
| Thinking Mode | ✅ Yes | reasoning_content for step-by-step |
| Function Calling | ✅ Yes | Full tool support |
| Context Caching | ✅ Yes | cached_tokens in usage |
| Structured Output | ✅ Yes | JSON mode available |

---

## Performance Metrics

| Metric | Value |
|--------|-------|
| Average Response Time | ~2000-4000 ms |
| Time to First Token | ~800-1500 ms |
| Context Window | 128K tokens |
| Max Output Tokens | 4,096 tokens |
| Quality Rating | ⭐⭐⭐⭐⭐ Premium |

---

## Use Cases

- **Complex Reasoning:** Multi-step analysis
- **Creative Writing:** Stories, scripts, poetry
- **Research Analysis:** Deep information synthesis
- **Code Generation:** Complex programming tasks
- **Problem Solving:** Advanced challenges

---

## Best Practices

1. **Provide Context:** Use the full context window for complex tasks
2. **Use Thinking Mode:** Enable for step-by-step reasoning
3. **Be Specific:** Clear prompts lead to better results
4. **Allow Time:** Premium models need more processing time

---

*Report generated: 2026-04-01T10:27:33.835Z*
