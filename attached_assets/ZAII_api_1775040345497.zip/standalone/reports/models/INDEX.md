# GLM Model Reports

This directory contains detailed documentation for all 12 tested GLM models.

## Language Models (7)

| # | Model | Category | Description |
|---|-------|----------|-------------|
| 01 | [glm-4.5](01-glm-4.5.md) | Stable Baseline | Reliable language model for general use |
| 02 | [glm-4.5-air](02-glm-4.5-air.md) | Lightweight | Speed and cost-optimized variant |
| 03 | [glm-4.5-flash](03-glm-4.5-flash.md) | Ultra-Fast | Real-time applications requiring instant responses |
| 04 | [glm-4.6](04-glm-4.6.md) | Enhanced | Quality improvements with Thinking Mode |
| 05 | [glm-4.7](05-glm-4.7.md) | Enhanced | Latest 4.x series improvements |
| 06 | [glm-5](06-glm-5.md) | Premium | Deep thinking and complex reasoning tasks |
| 07 | [glm-5-turbo](07-glm-5-turbo.md) | Performance | Fast premium model for complex tasks |
| 08 | [glm-5.1](08-glm-5.1.md) | Latest | Cutting-edge architecture with state-of-the-art quality |

## Vision Models (4)

| # | Model | Category | Description |
|---|-------|----------|-------------|
| 09 | [glm-4.6v](09-glm-4.6v.md) | High-Quality Vision | Advanced image understanding and analysis |
| 10 | [glm-4.6v-flash](10-glm-4.6v-flash.md) | Fast Vision | Real-time image processing |
| 11 | [glm-4.5v](11-glm-4.5v.md) | Document Vision | OCR and document processing |
| 12 | [autoglm-phone-multilingual](12-autoglm-phone-multilingual.md) | Phone UI | Mobile interface understanding with multilingual support |

## Quick Reference

### Model Selection Guide

| Use Case | Recommended Model |
|----------|------------------|
| Complex reasoning | `glm-5` or `glm-5.1` |
| Fast chat | `glm-4.5-flash` |
| Coding assistant | `glm-5-turbo` |
| Image analysis | `glm-4.6v` |
| OCR/Documents | `glm-4.5v` |
| Cost optimization | `glm-4.5-air` |
| General use | `glm-4.6` or `glm-4.7` |

### Feature Matrix

| Feature | 4.5 | 4.5-air | 4.5-flash | 4.6 | 4.7 | 5 | 5-turbo | 5.1 |
|---------|-----|---------|-----------|-----|-----|---|---------|-----|
| Text Generation | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Streaming | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Thinking Mode | ✅ | ⚠️ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Function Calling | ✅ | ✅ | ⚠️ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Context Caching | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| JSON Mode | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Context Window | 128K | 128K | 32K | 128K | 128K | 128K | 128K | 128K |

## API Endpoints

All models support three API protocols:

| API Type | Endpoint | Protocol |
|----------|----------|----------|
| General | `https://api.z.ai/api/paas/v4/chat/completions` | OpenAI Compatible |
| Coding | `https://api.z.ai/api/coding/paas/v4/chat/completions` | OpenAI Compatible |
| Anthropic | `https://api.z.ai/api/anthropic/v1/messages` | Anthropic Compatible |

## Report Structure

Each model report includes:
- Model Overview (ID, Status, Category)
- API Endpoints
- Quick Start Example (with real request/response)
- Features table
- Performance Metrics
- Use Cases
- Best Practices
- Comparison with other models

## Test Results

All 12 models were tested successfully on April 1, 2026. See the main [index.html](../index.html) for detailed test results.
