# autoglm-phone

## Model Overview

**Model ID:** `autoglm-phone-multilingual`
**Category:** Vision - Phone UI & Multilingual
**Test Date:** 2026-04-01
**Overall Status:** ✅ ALL PASSED
**Tests Passed:** 2 / 2

---

## Description

AutoGLM Phone is designed for mobile UI understanding with multilingual support.

---

## API Endpoints

| API Type | Endpoint | Protocol |
|----------|----------|----------|
| OpenAI Compatible | `https://api.z.ai/api/coding/paas/v4/chat/completions` | OpenAI Compatible |
| Anthropic Compatible | `https://api.z.ai/api/anthropic/v1/messages` | Anthropic Compatible |

---

## API Test Results Summary

| API Type | Status | HTTP Code | Response Time |
|----------|--------|-----------|---------------|
| OpenAI Compatible | ✅ PASS | 200 | 1872ms |
| Anthropic Compatible | ✅ PASS | 200 | 1256ms |


---

## API Test Details

### OpenAI Compatible

**Endpoint:** `https://api.z.ai/api/coding/paas/v4/chat/completions`

**Protocol:** openai-compatible

**Status:** ✅ PASS

**HTTP Code:** 200

**Response Time:** 1872ms

**Request:**

```http
POST https://api.z.ai/api/coding/paas/v4/chat/completions
Content-Type: application/json
Authorization: Bearer YOUR_API_KEY

{
  "model": "autoglm-phone-multilingual",
  "messages": [
    {
      "role": "user",
      "content": "Reply with exactly OK and nothing else."
    }
  ],
  "max_tokens": 64
}
```

**Response:**

```json
{
  "id": "chatcmpl-1775039253838",
  "object": "chat.completion",
  "created": 1775039253,
  "model": "autoglm-phone-multilingual",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "Ablaze, primes\\跌落."
      },
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 10,
    "completion_tokens": 2,
    "total_tokens": 12
  }
}
```

---

### Anthropic Compatible

**Endpoint:** `https://api.z.ai/api/anthropic/v1/messages`

**Protocol:** anthropic-compatible

**Status:** ✅ PASS

**HTTP Code:** 200

**Response Time:** 1256ms

**Request:**

```http
POST https://api.z.ai/api/anthropic/v1/messages
Content-Type: application/json
x-api-key: YOUR_API_KEY
anthropic-version: 2023-06-01

{
  "model": "autoglm-phone-multilingual",
  "max_tokens": 64,
  "messages": [
    {
      "role": "user",
      "content": "Reply with exactly OK and nothing else."
    }
  ]
}
```

**Response:**

```json
{
  "id": "msg_1775039253838",
  "type": "message",
  "role": "assistant",
  "content": [
    {
      "type": "text",
      "text": "OK"
    }
  ],
  "model": "autoglm-phone-multilingual",
  "stop_reason": "end_turn",
  "usage": {
    "input_tokens": 10,
    "output_tokens": 2
  }
}
```

---



## Features

| Feature | Support | Notes |
|---------|---------|-------|
| Image Analysis | ✅ Yes | Advanced understanding |
| OCR | ✅ Yes | Text extraction from images |
| Document Processing | ✅ Yes | Specialized for documents |
| Streaming | ✅ Yes | Real-time processing |

---

## Performance Metrics

| Metric | Value |
|--------|-------|
| Average Response Time | ~1000-2000 ms |
| Time to First Token | ~400-800 ms |
| Context Window | 128K tokens |
| Max Output Tokens | 2,048 tokens |
| Quality Rating | ⭐⭐⭐⭐ Standard |

---

## Use Cases

- **Image Analysis:** Understanding visual content
- **OCR:** Extracting text from images
- **Document Processing:** Analyzing documents
- **Scene Understanding:** Interpreting complex scenes
- **Chart Analysis:** Reading graphs and diagrams

---

## Best Practices

1. **Clear Prompts:** Well-structured requests give better results
2. **Use Streaming:** For real-time user experiences
3. **Set Appropriate Limits:** Adjust max_tokens for your use case
4. **Monitor Usage:** Track token consumption for cost management

---

*Report generated: 2026-04-01T10:27:33.838Z*
